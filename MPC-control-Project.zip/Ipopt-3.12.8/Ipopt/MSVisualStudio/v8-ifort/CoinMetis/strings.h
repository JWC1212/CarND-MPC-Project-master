// Copyright (C) 2009 Paragon Decision Technology B.V.
// All Rights Reserved.
// This code is published under the Eclipse Public License.
//
// Authors:  Marcel Roelofs	Paragon Decision Technology B.V. 2009-10-25

// Dummy include file to account for missing strings.h header file used in Metis source in MSVC 8.

#ifndef _INCLUDED_STRINGS_H_
#define _INCLUDED_STRINGS_H_ 
#include <string.h>
#endif
